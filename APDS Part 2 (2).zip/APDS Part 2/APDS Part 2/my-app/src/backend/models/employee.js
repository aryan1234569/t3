const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const validator = require('validator');

const employeeSchema = new mongoose.Schema({
    username: { 
        type: String, 
        required: true, 
        unique: true,
        validate: {
            validator: function(v) {
                return /^[a-zA-Z0-9]+$/.test(v); // Alphanumeric only
            },
            message: 'Username must be alphanumeric'
        }
    },
    email: { 
        type: String, 
        required: true, 
        unique: true, 
        validate: [validator.isEmail, 'Invalid email format']
    },
    employeeId: { 
        type: String, 
        required: true, 
        unique: true, 
        validate: {
            validator: function(v) {
                return /^[0-9]+$/.test(v); // Numeric only
            },
            message: 'Employee ID must contain only numbers'
        }
    },
    password: { 
        type: String, 
        required: true, 
        validate: {
            validator: function (v) {
                return v.length >= 8 && /[A-Z]/.test(v) && /\d/.test(v); // At least 8 chars, one uppercase, and one number
            },
            message: 'Password must be at least 8 characters, contain a number and an uppercase letter'
        }
    }
});

// Password hashing and salting
employeeSchema.pre('save', async function (next) {
    if (!this.isModified('password')) return next();
    try {
        const hash = await bcrypt.hash(this.password, 12);
        this.password = hash;
        next();
    } catch (err) {
        console.error('Error hashing password:', err); // Log password hashing error
        return next(err);
    }
});

// Password comparison method
employeeSchema.methods.comparePassword = async function (password) {
    return bcrypt.compare(password, this.password);
};

module.exports = mongoose.model('Employee', employeeSchema);
