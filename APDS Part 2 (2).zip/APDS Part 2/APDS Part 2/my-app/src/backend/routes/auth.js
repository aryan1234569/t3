const express = require('express');
const User = require('../models/user');
const Employee = require('../models/employee');
const jwt = require('jsonwebtoken');
const expressBrute = require('express-brute');
const router = express.Router();

// Brute-force protection
const bruteForce = new expressBrute.MemoryStore();
const bruteLimiter = new expressBrute(bruteForce);

// Middleware to parse JSON requests
router.use(express.json());

// Registration Route for Users
router.post('/register', async (req, res) => {
    const { username, email, accountNumber, password } = req.body;

    if (!username || !email || !accountNumber || !password) {
        return res.status(400).json({ message: 'All fields are required' });
    }

    try {
        const existingUser = await User.findOne({ username });
        if (existingUser) {
            return res.status(400).json({ message: 'User already exists' });
        }

        const newUser = new User({ username, email, accountNumber, password });
        await newUser.save();
        res.status(201).json({ message: 'User registered successfully' });
    } catch (error) {
        console.error('Registration error:', error);
        if (error.code === 11000) {
            return res.status(400).json({ message: `Duplicate field: ${Object.keys(error.keyValue)[0]} already exists` });
        } else if (error.name === 'ValidationError') {
            return res.status(400).json({ message: error.message });
        }
        res.status(500).json({ message: 'Server error', error });
    }
});

// Registration Route for Employees
router.post('/register-employee', async (req, res) => {
    const { username, email, employeeId, password } = req.body;

    if (!username || !email || !employeeId || !password) {
        return res.status(400).json({ message: 'All fields are required' });
    }

    try {
        const existingEmployee = await Employee.findOne({ username });
        if (existingEmployee) {
            return res.status(400).json({ message: 'Employee already exists' });
        }

        const newEmployee = new Employee({ username, email, employeeId, password });
        await newEmployee.save();
        res.status(201).json({ message: 'Employee registered successfully' });
    } catch (error) {
        console.error('Registration error:', error);
        if (error.code === 11000) {
            return res.status(400).json({ message: `Duplicate field: ${Object.keys(error.keyValue)[0]} already exists` });
        } else if (error.name === 'ValidationError') {
            return res.status(400).json({ message: error.message });
        }
        res.status(500).json({ message: 'Server error', error });
    }
});

// Login Route for Users
router.post('/login', bruteLimiter.prevent, async (req, res) => {
    const { email, password } = req.body;
    try {
        const user = await User.findOne({ email });
        if (!user) return res.status(401).send('Invalid credentials');
        const isMatch = await user.comparePassword(password);
        if (!isMatch) return res.status(401).send('Invalid credentials');

        const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });
        res.json({ token });
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).send('Server error');
    }
});

// Login Route for Employees
router.post('/login-employee', bruteLimiter.prevent, async (req, res) => {
    const { email, password } = req.body;
    try {
        const employee = await Employee.findOne({ email });
        if (!employee) return res.status(401).send('Invalid credentials');
        const isMatch = await employee.comparePassword(password);
        if (!isMatch) return res.status(401).send('Invalid credentials');

        const token = jwt.sign({ employeeId: employee._id }, process.env.JWT_SECRET, { expiresIn: '1h' });
        res.json({ token });
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).send('Server error');
    }
});

module.exports = router;
