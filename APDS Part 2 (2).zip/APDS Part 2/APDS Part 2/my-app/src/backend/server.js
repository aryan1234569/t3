const express = require('express');
const mongoose = require('mongoose');
const fs = require('fs');
const https = require('https');
const helmet = require('helmet'); // Helmet for security
const cors = require('cors');
const cookieParser = require('cookie-parser'); // Import cookie-parser
const authRoutes = require('./routes/auth'); // Adjust the path if needed
require('dotenv').config(); // Load environment variables

const app = express();

// SSL Certificates for HTTPS
const options = {
  key: fs.readFileSync('ssl/key.pem'),
  cert: fs.readFileSync('ssl/cert.pem'),
};

// Middleware setup
app.use(cors({
  origin: 'http://localhost:3000', // Your frontend URL
  credentials: true, // Allow credentials for cookies
}));
app.use(cookieParser()); // Use cookie parser middleware
app.use(express.json());
app.use(helmet());

// MongoDB connection
mongoose.connect('mongodb://localhost/customer-portal', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB connection error:', err));

// Routes
app.use('/api/auth', authRoutes);

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err); // Log error details
  res.status(500).json({ message: 'Internal Server Error' });
});

// Start HTTPS server
https.createServer(options, app).listen(5000, () => {
  console.log('Secure server running on port 5000');
});
