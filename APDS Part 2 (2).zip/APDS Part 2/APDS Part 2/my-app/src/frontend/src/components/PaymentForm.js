import React, { useState } from 'react';
import axios from 'axios';
import DOMPurify from 'dompurify';

function PaymentForm() {
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState('USD');
  const [swiftCode, setSwiftCode] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  // Regex patterns for validation
  const amountPattern = /^\d+(\.\d{1,2})?$/; // Allow only numbers, optional decimal
  const swiftCodePattern = /^[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?$/; // SWIFT code pattern
  const accountNumberPattern = /^\d{10,12}$/; // Account number (10 to 12 digits)

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate inputs
    if (!amountPattern.test(amount)) {
      setErrorMessage('Invalid amount format.');
      return;
    }
    if (!swiftCodePattern.test(swiftCode)) {
      setErrorMessage('Invalid SWIFT code format.');
      return;
    }
    if (!accountNumberPattern.test(accountNumber)) {
      setErrorMessage('Invalid account number format.');
      return;
    }

    // Sanitize input values before sending to the server
    const sanitizedAmount = DOMPurify.sanitize(amount);
    const sanitizedSwiftCode = DOMPurify.sanitize(swiftCode);
    const sanitizedAccountNumber = DOMPurify.sanitize(accountNumber);

    try {
      const response = await axios.post('https://localhost/api/payments', {
        amount: sanitizedAmount,
        currency,
        swiftCode: sanitizedSwiftCode,
        accountNumber: sanitizedAccountNumber,
      });
      alert('Payment initiated successfully');
    } catch (error) {
      console.error('Payment error:', error); // Log the full error for debugging
      setErrorMessage('Payment failed: ' + (error.response?.data?.message || 'Unknown error'));
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Initiate Payment</h2>
      <input 
        type="number" 
        placeholder="Amount" 
        value={amount} 
        onChange={(e) => setAmount(e.target.value)} 
        required 
      />
      <select value={currency} onChange={(e) => setCurrency(e.target.value)}>
        <option value="USD">USD</option>
        <option value="EUR">EUR</option>
        <option value="ZAR">ZAR</option>
      </select>
      <input 
        type="text" 
        placeholder="SWIFT Code" 
        value={swiftCode} 
        onChange={(e) => setSwiftCode(e.target.value)} 
        required 
      />
      <input 
        type="text" 
        placeholder="Account Number" 
        value={accountNumber} 
        onChange={(e) => setAccountNumber(e.target.value)} 
        required 
      />
      <button type="submit">Initiate Payment</button>
      {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}
    </form>
  );
}

export default PaymentForm;
