import React, { useState } from 'react';
import axios from 'axios';

function Register() {
  const [isEmployee, setIsEmployee] = useState(false);
  const [fullName, setFullName] = useState('');
  const [idNumber, setIdNumber] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [employeeId, setEmployeeId] = useState(''); // For employee registration
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  // Regular expressions for input validation
  const idRegex = /^[0-9]{13}$/; // South African ID format
  const accountNumberRegex = /^[0-9]{10,12}$/; // Example account number format
  const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/; // Min 8 chars, letters, numbers

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Input validation
    if (!idRegex.test(idNumber)) {
      setErrorMessage('Invalid ID number');
      return;
    }
    if (!accountNumberRegex.test(accountNumber)) {
      setErrorMessage('Invalid account number');
      return;
    }
    if (!passwordRegex.test(password)) {
      setErrorMessage('Password must be at least 8 characters long and include letters and numbers');
      return;
    }

    const url = isEmployee ? 'https://localhost:5000/api/auth/register-employee' : 'https://localhost:5000/api/auth/register';

    try {
      const response = await axios.post(url, {
        fullName,
        idNumber,
        accountNumber,
        username,
        email,
        employeeId: isEmployee ? employeeId : undefined, // Send employeeId only for employee registration
        password,
      }, { 
        withCredentials: true // Ensure credentials are included
      });

      alert(response.data.message);
    } catch (error) {
      console.error('Registration error status:', error.response?.status); // Log the status code
      console.error('Registration error:', error.response?.data || error); 
      setErrorMessage(error.response?.data?.message || 'Registration failed');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>{isEmployee ? 'Employee Registration' : 'User Registration'}</h2>
      <input type="text" placeholder="Full Name" value={fullName} onChange={(e) => setFullName(e.target.value)} required />
      <input type="text" placeholder="ID Number" value={idNumber} onChange={(e) => setIdNumber(e.target.value)} required />
      <input type="text" placeholder="Account Number" value={accountNumber} onChange={(e) => setAccountNumber(e.target.value)} required />
      <input type="text" placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} required />
      <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
      {isEmployee && (
        <input type="text" placeholder="Employee ID" value={employeeId} onChange={(e) => setEmployeeId(e.target.value)} required />
      )}
      <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} required />
      <button type="submit">{isEmployee ? 'Register Employee' : 'Register'}</button>
      {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}
      <label>
        <input type="checkbox" checked={isEmployee} onChange={() => setIsEmployee(!isEmployee)} />
        Register as Employee
      </label>
    </form>
  );
}

export default Register;
