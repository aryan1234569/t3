import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import Login from './frontend/src/components/Login';
import Register from './frontend/src/components/Register';
import EmployeeLogin from './frontend/src/components/EmployeeLogin';
import PaymentForm from './frontend/src/components/PaymentForm';
import './App.css'; // Add your CSS file for styling

function App() {
  return (
    <Router>
      <div className="App">
        <h1>Welcome to the International Payments Portal</h1>
        {/* Navigation Links */}
        <nav>
          <ul>
            <li><Link to="/login">Login</Link></li>
            <li><Link to="/register">Register</Link></li>
            <li><Link to="/employee/login">Employee Login</Link></li>
            <li><Link to="/payments">Payments</Link></li>
          </ul>
        </nav>

        <Routes>
          <Route path="/employee/login" element={<EmployeeLogin />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/payments" element={<PaymentForm />} />
          <Route path="/" element={<p>Please choose an option above.</p>} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
